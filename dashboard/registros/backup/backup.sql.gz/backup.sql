-- Generation time: Fri, 01 Jun 2018 18:04:56 +0200
-- Host: localhost
-- DB name: barolo
/*!40030 SET NAMES UTF8 */;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP TABLE IF EXISTS `acciones`;
CREATE TABLE `acciones` (
  `id_accion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_accion` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion_accion` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_accion`),
  UNIQUE KEY `id_accion` (`id_accion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;



DROP TABLE IF EXISTS `cargos`;
CREATE TABLE `cargos` (
  `IdCargo` int(11) NOT NULL AUTO_INCREMENT,
  `NombreCargo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Descripcion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdCargo`),
  UNIQUE KEY `NombreCargo` (`NombreCargo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `cargos` VALUES ('1','Root','Dios'),
('2','Administrador','Due�o'),
('3','Hotelero','trabajador de hotel'); 


DROP TABLE IF EXISTS `categorialavanderia`;
CREATE TABLE `categorialavanderia` (
  `IdCategoria` int(11) NOT NULL AUTO_INCREMENT,
  `Categoria` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdCategoria`),
  UNIQUE KEY `Categoria` (`Categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `categorialavanderia` VALUES ('1','higiene'),
('3','manteleria'),
('2','ropa de cama'); 


DROP TABLE IF EXISTS `categoriaproducto`;
CREATE TABLE `categoriaproducto` (
  `IdCategoria` int(11) NOT NULL AUTO_INCREMENT,
  `CategoriaProducto` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdCategoria`),
  UNIQUE KEY `CategoriaProducto` (`CategoriaProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `categoriaproducto` VALUES ('1','Almuerzo'),
('7','Bebida'),
('3','Cena'),
('6','desayuno'),
('9','Entrada'),
('8','Postre'); 


DROP TABLE IF EXISTS `cuentatotal`;
CREATE TABLE `cuentatotal` (
  `IdCuenta` int(11) NOT NULL AUTO_INCREMENT,
  `IdEnte` int(11) NOT NULL,
  `Fecha` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdCuenta`),
  KEY `IdEnte` (`IdEnte`),
  CONSTRAINT `cuentatotal_ibfk_1` FOREIGN KEY (`IdEnte`) REFERENCES `entes` (`IdEnte`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `cuentatotal` VALUES ('1','2','12/06/18'),
('2','1','12/06/18'); 


DROP TABLE IF EXISTS `detalleconferencia`;
CREATE TABLE `detalleconferencia` (
  `IdReserva` int(11) NOT NULL AUTO_INCREMENT,
  `IdSala` int(11) NOT NULL,
  `IdMesa` int(11) NOT NULL,
  `CantidadMesas` int(11) NOT NULL,
  `IdSilla` int(11) NOT NULL,
  `CantidadSillas` int(11) NOT NULL,
  `HoraInicio` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `HoraFin` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Fecha` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `IdCuenta` int(11) NOT NULL,
  PRIMARY KEY (`IdReserva`),
  KEY `IdSala` (`IdSala`),
  KEY `IdMesa` (`IdMesa`),
  KEY `IdSilla` (`IdSilla`),
  KEY `IdCuenta` (`IdCuenta`),
  CONSTRAINT `detalleconferencia_ibfk_1` FOREIGN KEY (`IdMesa`) REFERENCES `mesas` (`IdMesa`),
  CONSTRAINT `detalleconferencia_ibfk_2` FOREIGN KEY (`IdSala`) REFERENCES `salas` (`IdSala`),
  CONSTRAINT `detalleconferencia_ibfk_3` FOREIGN KEY (`IdSilla`) REFERENCES `sillas` (`IdSilla`),
  CONSTRAINT `detalleconferencia_ibfk_4` FOREIGN KEY (`IdCuenta`) REFERENCES `cuentatotal` (`IdCuenta`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `detalleconferencia` VALUES ('1','1','1','21','1','232','02:32','02:32','2018-06-21','1'); 


DROP TABLE IF EXISTS `detallereserva`;
CREATE TABLE `detallereserva` (
  `IdDetalle` int(11) NOT NULL AUTO_INCREMENT,
  `FechaInicio` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `FechaFin` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `HoraInicio` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `IdHabitacion` int(11) NOT NULL,
  `HoraFin` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `IdCuenta` int(11) NOT NULL,
  PRIMARY KEY (`IdDetalle`),
  KEY `IdHabitacion` (`IdHabitacion`),
  KEY `IdCuenta` (`IdCuenta`),
  CONSTRAINT `detallereserva_ibfk_1` FOREIGN KEY (`IdHabitacion`) REFERENCES `habitaciones` (`IdHabitacion`),
  CONSTRAINT `detallereserva_ibfk_2` FOREIGN KEY (`IdCuenta`) REFERENCES `cuentatotal` (`IdCuenta`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `detallereserva` VALUES ('1','2018-06-28','2018-06-28','15:21','11','00:12','1'),
('3','2018-06-28','2018-06-14','02:13','6','14:33','1'); 


DROP TABLE IF EXISTS `detallerestaurante`;
CREATE TABLE `detallerestaurante` (
  `IdDetalle` int(11) NOT NULL AUTO_INCREMENT,
  `Cantidad` int(11) NOT NULL,
  `IdProducto` int(11) NOT NULL,
  `IdCuenta` int(11) NOT NULL,
  `IdMesa` int(11) NOT NULL,
  PRIMARY KEY (`IdDetalle`),
  KEY `IdBebida` (`IdProducto`),
  KEY `IdCuenta` (`IdCuenta`),
  KEY `IdMesa` (`IdMesa`),
  CONSTRAINT `detallerestaurante_ibfk_1` FOREIGN KEY (`IdProducto`) REFERENCES `productos` (`IdProducto`),
  CONSTRAINT `detallerestaurante_ibfk_2` FOREIGN KEY (`IdCuenta`) REFERENCES `cuentatotal` (`IdCuenta`),
  CONSTRAINT `detallerestaurante_ibfk_3` FOREIGN KEY (`IdMesa`) REFERENCES `mesarestaurante` (`IdMesaRes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;



DROP TABLE IF EXISTS `empleados`;
CREATE TABLE `empleados` (
  `IdEmpleado` int(11) NOT NULL AUTO_INCREMENT,
  `NombreEmpleado` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `ApellidosEmpleado` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `DUIEmpleado` int(11) NOT NULL,
  `TelefonoEmpleado` int(11) NOT NULL,
  `DireccionEmpleado` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `FotoEmpleado` varchar(1000) COLLATE utf8_spanish_ci NOT NULL,
  `IdCargo` int(11) NOT NULL,
  `IdGenero` int(11) NOT NULL,
  PRIMARY KEY (`IdEmpleado`),
  KEY `IdCargo` (`IdCargo`),
  KEY `IdGenero` (`IdGenero`),
  CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`IdCargo`) REFERENCES `cargos` (`IdCargo`),
  CONSTRAINT `empleados_ibfk_2` FOREIGN KEY (`IdGenero`) REFERENCES `genero` (`IdGenero`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `empleados` VALUES ('1','Daniel','Barrera','356151515','515151515','San salvador','DANICX.JPG','1','2'),
('2','w','j','2121','122','f','e','3','1'),
('3','j','j','2121','122','f','e','2','1'),
('4','dwef','bhbh','7667','766','gtdewte','5b0f5acadcf98.jpg','3','1'),
('5','Estefany','Aguirre','12345','12345','gdhr','5b0f5b1c83bda.jpg','2','2'),
('6','rjjnj','njnjnj','8787','8787878','hhj','5b10b957f03a7.jpg','2','1'); 


DROP TABLE IF EXISTS `entes`;
CREATE TABLE `entes` (
  `IdEnte` int(11) NOT NULL AUTO_INCREMENT,
  `Nombres` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Apellidos` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `DocIdentidad` int(11) NOT NULL,
  `Correo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Telefono` int(11) NOT NULL,
  `IdGenero` int(11) NOT NULL,
  `IdTipo` int(11) NOT NULL,
  PRIMARY KEY (`IdEnte`),
  KEY `IdGenero` (`IdGenero`),
  KEY `IdTipo` (`IdTipo`),
  CONSTRAINT `entes_ibfk_1` FOREIGN KEY (`IdGenero`) REFERENCES `genero` (`IdGenero`),
  CONSTRAINT `entes_ibfk_2` FOREIGN KEY (`IdTipo`) REFERENCES `tipoente` (`IdTipo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `entes` VALUES ('1','Roland','Van','123456','sds@mdkf.co','12345678','1','2'),
('2','Andres','Martinez','12345678','andresguapo@gmail.com','54896624','1','2'); 


DROP TABLE IF EXISTS `estado`;
CREATE TABLE `estado` (
  `IdEstado` int(11) NOT NULL AUTO_INCREMENT,
  `Estado` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdEstado`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `estado` VALUES ('1','Disponible'),
('2','Ocupada'); 


DROP TABLE IF EXISTS `genero`;
CREATE TABLE `genero` (
  `IdGenero` int(11) NOT NULL,
  `NombreGenero` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdGenero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `genero` VALUES ('1','Masculino'),
('2','Femenino'); 


DROP TABLE IF EXISTS `habitaciones`;
CREATE TABLE `habitaciones` (
  `IdHabitacion` int(11) NOT NULL AUTO_INCREMENT,
  `NumeroHabitacion` int(11) NOT NULL,
  `Capacidad` int(11) NOT NULL,
  `Precio` double(6,2) NOT NULL,
  `IdTipoHabitacion` int(11) NOT NULL,
  `IdEstado` int(11) NOT NULL,
  PRIMARY KEY (`IdHabitacion`),
  KEY `IdTipoHabitacion` (`IdTipoHabitacion`),
  KEY `IdEstado` (`IdEstado`),
  CONSTRAINT `habitaciones_ibfk_1` FOREIGN KEY (`IdEstado`) REFERENCES `estado` (`IdEstado`),
  CONSTRAINT `habitaciones_ibfk_2` FOREIGN KEY (`IdTipoHabitacion`) REFERENCES `tipohabitacion` (`IdTipoHabitacion`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `habitaciones` VALUES ('6','102','2','30.00','1','1'),
('8','2','2','89.99','2','2'),
('9','69','2','69.00','2','1'),
('10','22','4','40.00','1','1'),
('11','40','1','70.00','2','1'),
('12','12','5','120.00','6','1'); 


DROP TABLE IF EXISTS `lavanderia`;
CREATE TABLE `lavanderia` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Color` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `IdEstado` int(11) NOT NULL,
  `IdCategoria` int(11) NOT NULL,
  `IdMaterial` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IdEstado` (`IdEstado`),
  KEY `IdCategoria` (`IdCategoria`),
  KEY `IdMaterial` (`IdMaterial`),
  CONSTRAINT `lavanderia_ibfk_1` FOREIGN KEY (`IdEstado`) REFERENCES `estado` (`IdEstado`),
  CONSTRAINT `lavanderia_ibfk_2` FOREIGN KEY (`IdCategoria`) REFERENCES `categorialavanderia` (`IdCategoria`),
  CONSTRAINT `lavanderia_ibfk_3` FOREIGN KEY (`IdMaterial`) REFERENCES `material` (`IdMaterial`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `lavanderia` VALUES ('1','Toalla','75','blanco','1','1','1'),
('2','edredon','76','ocre','1','2','2'),
('3','mantel largo','20','azul','1','3','2'); 


DROP TABLE IF EXISTS `material`;
CREATE TABLE `material` (
  `IdMaterial` int(11) NOT NULL AUTO_INCREMENT,
  `Material` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdMaterial`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `material` VALUES ('1','algodon'),
('2','lino'); 


DROP TABLE IF EXISTS `mesarestaurante`;
CREATE TABLE `mesarestaurante` (
  `IdMesaRes` int(11) NOT NULL AUTO_INCREMENT,
  `NumeroMesa` int(11) NOT NULL,
  `Capacidad` int(11) NOT NULL,
  `IdEstado` int(11) NOT NULL,
  PRIMARY KEY (`IdMesaRes`),
  KEY `IdEstado` (`IdEstado`),
  CONSTRAINT `mesarestaurante_ibfk_1` FOREIGN KEY (`IdEstado`) REFERENCES `estado` (`IdEstado`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `mesarestaurante` VALUES ('1','1','6','1'),
('2','2','6','1'),
('3','3','6','1'),
('4','4','8','1'),
('5','5','8','1'),
('6','6','5','1'); 


DROP TABLE IF EXISTS `mesas`;
CREATE TABLE `mesas` (
  `IdMesa` int(11) NOT NULL AUTO_INCREMENT,
  `Cantidad` int(11) NOT NULL,
  `Nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdMesa`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `mesas` VALUES ('1','30','Redonda'); 


DROP TABLE IF EXISTS `pedidohabitacion`;
CREATE TABLE `pedidohabitacion` (
  `IdPedido` int(11) NOT NULL AUTO_INCREMENT,
  `FechaPedido` varchar(12) COLLATE utf8_spanish_ci NOT NULL,
  `IdDetalleRes` int(11) NOT NULL,
  `IdHabitacion` int(11) NOT NULL,
  `IdCuenta` int(11) NOT NULL,
  PRIMARY KEY (`IdPedido`),
  KEY `IdDetallePlato` (`IdDetalleRes`),
  KEY `IdHabitacion` (`IdHabitacion`),
  KEY `IdCuenta` (`IdCuenta`),
  CONSTRAINT `pedidohabitacion_ibfk_4` FOREIGN KEY (`IdHabitacion`) REFERENCES `habitaciones` (`IdHabitacion`),
  CONSTRAINT `pedidohabitacion_ibfk_5` FOREIGN KEY (`IdDetalleRes`) REFERENCES `detallerestaurante` (`IdDetalle`),
  CONSTRAINT `pedidohabitacion_ibfk_6` FOREIGN KEY (`IdCuenta`) REFERENCES `cuentatotal` (`IdCuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;



DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `IdProducto` int(11) NOT NULL AUTO_INCREMENT,
  `NombreProducto` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Descripcion` varchar(90) COLLATE utf8_spanish_ci NOT NULL,
  `Precio` double(6,2) NOT NULL,
  `IdTipo` int(11) NOT NULL,
  `IdCategoria` int(11) NOT NULL,
  PRIMARY KEY (`IdProducto`),
  KEY `IdTamanio` (`IdTipo`),
  KEY `IdTipoBebida` (`IdCategoria`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`IdTipo`) REFERENCES `tipoproducto` (`IdTipo`),
  CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`IdCategoria`) REFERENCES `categoriaproducto` (`IdCategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `productos` VALUES ('1','rib eye','Exquisita carne para deborar','49.99','2','1'),
('2','Brownie','Exquisito Brownie con chocolate derretido que te hara volar a las estrellas con su sabor','6.75','1','1'),
('3','Estofado especial','Sabroso estofado al estilo nordico','12.00','3','3'),
('4','Budweiser','Bebida de los dioses','2.10','5','1'),
('5','Ensalada cesar','Tipica ensalada ','4.99','4','1'),
('6','Jugo de Naranja','juguito','3.00','5','7'); 


DROP TABLE IF EXISTS `salas`;
CREATE TABLE `salas` (
  `IdSala` int(11) NOT NULL AUTO_INCREMENT,
  `NombreSala` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `Descripcion` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `Capacidad` int(11) NOT NULL,
  `Costo` double NOT NULL,
  `IdEstadoSala` int(11) NOT NULL,
  PRIMARY KEY (`IdSala`),
  KEY `IdEstadoSala` (`IdEstadoSala`),
  CONSTRAINT `salas_ibfk_1` FOREIGN KEY (`IdEstadoSala`) REFERENCES `estado` (`IdEstado`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `salas` VALUES ('1','Sala1','sala numero 1','50','30','1'),
('2','Sala 2','sala numero 2','12','12','1'); 


DROP TABLE IF EXISTS `sillas`;
CREATE TABLE `sillas` (
  `IdSilla` int(11) NOT NULL AUTO_INCREMENT,
  `Cantidad` int(11) NOT NULL,
  `Nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdSilla`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sillas` VALUES ('1','20','Formal'); 


DROP TABLE IF EXISTS `tipoente`;
CREATE TABLE `tipoente` (
  `IdTipo` int(11) NOT NULL AUTO_INCREMENT,
  `TipoEnte` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdTipo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipoente` VALUES ('2','Clientes'),
('3','Huesped'); 


DROP TABLE IF EXISTS `tipohabitacion`;
CREATE TABLE `tipohabitacion` (
  `IdTipoHabitacion` int(11) NOT NULL AUTO_INCREMENT,
  `TipoHabitacion` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdTipoHabitacion`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipohabitacion` VALUES ('1','Doble'),
('2','matrimonial'),
('3','Individual'),
('4','Party'),
('5','Suit'),
('6','PentHouse'); 


DROP TABLE IF EXISTS `tipomesa`;
CREATE TABLE `tipomesa` (
  `IdTipoMesa` int(11) NOT NULL AUTO_INCREMENT,
  `TipoMesa` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdTipoMesa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;



DROP TABLE IF EXISTS `tipoproducto`;
CREATE TABLE `tipoproducto` (
  `IdTipo` int(11) NOT NULL AUTO_INCREMENT,
  `TipoProducto` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdTipo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipoproducto` VALUES ('1','postre'),
('2','plato principal'),
('3','sopa'),
('4','ensalada'),
('5','bebida'),
('6','Entrada'),
('7','Jugos'),
('8','Alcohol'); 


DROP TABLE IF EXISTS `tiposilla`;
CREATE TABLE `tiposilla` (
  `IdTipoSilla` int(11) NOT NULL AUTO_INCREMENT,
  `TipoSilla` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`IdTipoSilla`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;



DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `IdUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `NombreUsuario` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `ClaveUsuario` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `IdEmpleado` int(11) NOT NULL,
  PRIMARY KEY (`IdUsuario`),
  UNIQUE KEY `NombreUsuario` (`NombreUsuario`),
  UNIQUE KEY `IdEmpleado` (`IdEmpleado`),
  KEY `IdEmpelado` (`IdEmpleado`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`IdEmpleado`) REFERENCES `empleados` (`IdEmpleado`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `usuarios` VALUES ('1','Danicx','$2y$10$T7rMlcMm8ZIqh.UjF0k1vOtoq96lFfzdndk2RfFWqrBMDGY2/a7Z6','1'),
('3','Es','$2y$10$ERHWnaABOIuGdvcl9Gp30OrkvzwCh12ovikDwwtEoBmBbNMW60ECy','2'),
('5','Estefany','$2y$10$o3Hml2lgnFptuFl47lKIteS5YQ0TUAHMtZw2BAX8MoiM/Qkyj0vVe','5'); 




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

